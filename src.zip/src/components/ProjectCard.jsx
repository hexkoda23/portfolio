import React from 'react'

export default function ProjectCard({ title, subtitle, status, description, tags, images, onClick }) {
  return (
    <div
      className="card"
      onClick={onClick}
      style={{ padding: '1.5rem', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: '1rem' }}
    >
      {/* Image */}
      {images?.[0] && (
        <div style={{ borderRadius: '8px', overflow: 'hidden', aspectRatio: '16/9', background: 'var(--bg-subtle)' }}>
          <img src={images[0]} alt={title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        </div>
      )}

      {/* Meta row */}
      <div className="flex items-center justify-between">
        <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '0.72rem', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--cta)' }}>
          {subtitle}
        </span>
        {status && (
          <span className="badge" style={{ background: 'var(--accent-subtle)', color: 'var(--cta)', borderColor: 'rgba(234,88,12,0.2)', fontSize: '0.68rem' }}>
            {status}
          </span>
        )}
      </div>

      {/* Title */}
      <h3 style={{ fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '1.2rem', fontWeight: 400, color: 'var(--text-primary)', lineHeight: 1.3, letterSpacing: '-0.02em' }}>
        {title}
      </h3>

      {/* Description */}
      <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
        {description}
      </p>

      {/* Tags */}
      {tags?.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: 'auto' }}>
          {tags.map(tag => (
            <span key={tag} className="badge">{tag}</span>
          ))}
        </div>
      )}
    </div>
  )
}
