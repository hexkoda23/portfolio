import React from 'react'

const stats = [
  { label: 'AI Projects', value: '9' },
  { label: 'Technologies', value: '15+' },
  { label: 'Production Ready', value: '100%' },
]

export default function Hero() {
  return (
    <section className="hero-gradient" style={{ paddingTop: '48px', paddingBottom: '64px', position: 'relative', overflow: 'hidden' }}>

      {/* Background orbs — light and dark */}
      <div className="hero-orb" style={{ position: 'absolute', width: 500, height: 500, top: 0, right: -100, background: 'radial-gradient(circle, rgba(249,115,22,0.12) 0%, transparent 70%)', zIndex: 0 }} />
      <div className="hero-orb dark:block hidden" style={{ position: 'absolute', width: 400, height: 400, bottom: -80, left: -80, background: 'radial-gradient(circle, rgba(249,115,22,0.08) 0%, transparent 70%)', zIndex: 0 }} />

      <div className="container relative z-10">
        <div className="grid lg:grid-cols-[1.15fr_0.85fr] gap-12 lg:gap-16 items-start" style={{ alignItems: 'start' }}>

          {/* Left — Text */}
          <div className="animate-fade-up">

            {/* Role pill */}
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-semibold mb-6"
              style={{ background: 'var(--accent-subtle)', color: 'var(--cta)', border: '1px solid rgba(234,88,12,0.2)', letterSpacing: '0.04em', textTransform: 'uppercase', fontFamily: 'DM Sans, sans-serif' }}
            >
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--cta)', display: 'inline-block', animation: 'pulse 2s infinite' }} />
              AI & Full-Stack Developer
            </div>

            <h1
              style={{
                fontFamily: 'Instrument Serif, Georgia, serif',
                fontSize: 'clamp(2.4rem, 5vw, 3.75rem)',
                fontWeight: 400,
                lineHeight: 1.12,
                letterSpacing: '-0.03em',
                color: 'var(--text-primary)',
                marginBottom: '1.5rem',
              }}
            >
              Building intelligent AI solutions that solve{' '}
              <em style={{ fontStyle: 'italic', color: 'var(--cta)' }}>real-world</em> problems.
            </h1>

            <p
              style={{
                fontSize: '1.05rem',
                lineHeight: 1.7,
                color: 'var(--text-secondary)',
                maxWidth: '540px',
                marginBottom: '2rem',
                fontFamily: 'DM Sans, sans-serif',
              }}
            >
              Specializing in NLP, Machine Learning, and AI system design. I build
              production-ready solutions that combine cutting-edge research with
              practical engineering to deliver measurable business value.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap gap-3" style={{ marginBottom: '2.75rem' }}>
              <a href="/portfolio" className="btn-primary">
                View portfolio
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </a>
              <a href="/contact" className="btn-secondary">Get in touch</a>
              <a
                href="/cv/tife-cv.pdf"
                download="Tife_CV.pdf"
                className="btn-secondary"
              >
                Download CV
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" />
                </svg>
              </a>
            </div>

            {/* Stats */}
            <div
              className="flex gap-8 pt-6"
              style={{ borderTop: '1px solid var(--border-color)' }}
            >
              {stats.map((s, i) => (
                <div key={s.label} className={`animate-fade-up animate-fade-up-delay-${i + 1}`}>
                  <p style={{ fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '2rem', fontWeight: 400, color: 'var(--text-primary)', lineHeight: 1, letterSpacing: '-0.04em' }}>
                    {s.value}
                  </p>
                  <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '0.72rem', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginTop: '4px' }}>
                    {s.label}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right — Photo card */}
          <div className="relative animate-fade-up animate-fade-up-delay-2">
            <div
              className="card"
              style={{ borderRadius: '16px', overflow: 'hidden', height: '460px', maxHeight: '60vh', position: 'relative' }}
            >
              <img
                src="/Image/mee.jpg"
                alt="Adeleke Kehinde - AI Developer"
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => {
                  e.target.style.display = 'none'
                  e.target.nextElementSibling.style.display = 'flex'
                }}
              />
              {/* Fallback */}
              <div
                style={{
                  display: 'none',
                  position: 'absolute', inset: 0,
                  alignItems: 'center', justifyContent: 'center',
                  background: 'linear-gradient(135deg, var(--bg-subtle) 0%, var(--bg-card) 100%)',
                  flexDirection: 'column', gap: 12
                }}
              >
                <div style={{ fontSize: '3.5rem' }}>👨💻</div>
                <p style={{ fontFamily: 'Instrument Serif', fontSize: '1.2rem', color: 'var(--text-primary)' }}>Adeleke Kehinde</p>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>AI Developer</p>
              </div>
            </div>

            {/* Floating status badge */}
            <div
              className="card"
              style={{
                position: 'absolute', bottom: -16, left: '50%', transform: 'translateX(-50%)',
                padding: '10px 18px', borderRadius: '10px', whiteSpace: 'nowrap',
                textAlign: 'center', minWidth: '220px',
              }}
            >
              <p style={{ fontSize: '0.82rem', fontWeight: 600, color: 'var(--text-primary)', fontFamily: 'DM Sans, sans-serif', letterSpacing: '-0.01em' }}>
                Current focus — Production AI Systems
              </p>
              <p style={{ fontSize: '0.73rem', color: 'var(--text-muted)', marginTop: 2 }}>
                Building scalable, intelligent solutions
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  )
}
