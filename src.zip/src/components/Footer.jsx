import React from 'react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer style={{ background: 'var(--bg-secondary)', borderTop: '1px solid var(--border-color)', marginTop: '6rem' }}>
      <div className="container">
        <div style={{ padding: '3rem 0 2rem', display: 'grid', gap: '2rem' }} className="md:grid-cols-[1fr_auto]">

          <div>
            <p style={{ fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '1.3rem', fontWeight: 400, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
              Adeleke Kehinde
            </p>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '0.875rem', color: 'var(--text-muted)', marginTop: '6px', maxWidth: '360px' }}>
              AI Developer building intelligent solutions for real-world problems. Based in Lagos, working globally.
            </p>
            <a
              href="mailto:kehindeadeleke92@gmail.com"
              style={{ display: 'inline-block', marginTop: '12px', fontSize: '0.875rem', fontWeight: 600, color: 'var(--cta)', textDecoration: 'none', fontFamily: 'DM Sans, sans-serif' }}
            >
              kehindeadeleke92@gmail.com
            </a>
          </div>

        </div>

        <div style={{ borderTop: '1px solid var(--border-color)', padding: '1.25rem 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            © {new Date().getFullYear()} Adeleke Kehinde. All rights reserved.
          </p>
          <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            Lagos, Nigeria
          </p>
        </div>
      </div>
    </footer>
  )
}
