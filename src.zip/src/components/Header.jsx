import React, { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'

const navItems = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  { label: 'Portfolio', to: '/portfolio' },
  { label: 'Contact', to: '/contact' },
]

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const loc = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const toggleTheme = () => {
    const root = document.documentElement
    const isDark = root.getAttribute('data-theme') === 'dark'
    root.setAttribute('data-theme', isDark ? 'light' : 'dark')
    root.classList.toggle('dark', !isDark)
    localStorage.setItem('theme', isDark ? 'light' : 'dark')
  }

  return (
    <header
      className="app-navbar"
      style={{ boxShadow: scrolled ? '0 1px 0 var(--border-color)' : 'none' }}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group" style={{ textDecoration: 'none' }}>
            <div
              className="h-9 w-9 rounded-lg flex items-center justify-center text-sm font-bold"
              style={{ background: 'var(--text-primary)', color: 'var(--bg-primary)', letterSpacing: '-0.02em' }}
            >
              AK
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-semibold leading-none" style={{ color: 'var(--text-primary)', fontFamily: 'DM Sans, sans-serif', letterSpacing: '-0.02em' }}>
                Adeleke Kehinde
              </p>
              <p className="text-xs leading-none mt-0.5" style={{ color: 'var(--text-muted)' }}>
                AI & Full-Stack Developer
              </p>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map(item => {
              const active = loc.pathname === item.to
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className="px-3.5 py-2 text-sm font-medium rounded-md transition-colors"
                  style={{
                    fontFamily: 'DM Sans, sans-serif',
                    color: active ? 'var(--text-primary)' : 'var(--text-muted)',
                    background: active ? 'var(--bg-subtle)' : 'transparent',
                    textDecoration: 'none',
                    letterSpacing: '-0.01em',
                  }}
                >
                  {item.label}
                </Link>
              )
            })}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="inline-flex items-center justify-center w-9 h-9 rounded-md transition-colors"
              style={{ border: '1px solid var(--border-color)', background: 'var(--bg-card)', color: 'var(--text-secondary)', cursor: 'pointer' }}
            >
              {/* Sun icon */}
              <span className="block dark:hidden">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>
                </svg>
              </span>
              {/* Moon icon */}
              <span className="hidden dark:block">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                </svg>
              </span>
            </button>

            {/* CTA */}
            <Link to="/contact" className="btn-primary hidden sm:inline-flex" style={{ fontSize: '0.8rem', padding: '8px 16px' }}>
              Let's talk
            </Link>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
              className="lg:hidden inline-flex items-center justify-center w-9 h-9 rounded-md"
              style={{ border: '1px solid var(--border-color)', background: 'var(--bg-card)', color: 'var(--text-secondary)', cursor: 'pointer' }}
            >
              <div className="flex flex-col gap-1.5 w-4">
                <span className={`block h-px w-full rounded transition-transform origin-center ${isOpen ? 'translate-y-[3px] rotate-45' : ''}`} style={{ background: 'currentColor' }} />
                <span className={`block h-px rounded transition-opacity ${isOpen ? 'opacity-0 w-3/4' : 'w-full opacity-100'}`} style={{ background: 'currentColor' }} />
                <span className={`block h-px w-full rounded transition-transform origin-center ${isOpen ? '-translate-y-[9px] -rotate-45' : ''}`} style={{ background: 'currentColor' }} />
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-72 opacity-100' : 'max-h-0 opacity-0'}`}
        style={{ borderTop: '1px solid var(--border-color)', background: 'var(--bg-card)' }}
      >
        <nav className="container py-4 flex flex-col gap-1">
          {navItems.map(item => {
            const active = loc.pathname === item.to
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setIsOpen(false)}
                className="px-3.5 py-2.5 text-sm font-medium rounded-md"
                style={{
                  color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
                  background: active ? 'var(--bg-subtle)' : 'transparent',
                  textDecoration: 'none',
                  letterSpacing: '-0.01em',
                  fontFamily: 'DM Sans, sans-serif',
                }}
              >
                {item.label}
              </Link>
            )
          })}
          <Link
            to="/contact"
            onClick={() => setIsOpen(false)}
            className="btn-primary mt-2 text-center justify-center"
          >
            Let's talk
          </Link>
        </nav>
      </div>
    </header>
  )
}
