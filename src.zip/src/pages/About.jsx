import React from 'react'

const roles = [
  {
    title: 'Data Annotation Specialist · Awarri',
    detail: 'Served as a key contributor to a high-precision computer vision project aimed at revolutionizing healthcare diagnostics through AI. Meticulously performed semantic segmentation and object detection tasks on complex hospital laboratory datasets. Ensured the production of high-quality, pixel-perfect training data, which was critical for building robust AI models capable of accurately detecting medical equipment and anomalies in real-world clinical environments.',
    year: 'Dec 2025 — Jan 2025'
  },
  {
    title: 'AI Developer · Nigerian Communications Commission (NCC)',
    detail: 'Spearheaded the strategic integration of cutting-edge AI technologies into national regulatory frameworks, significantly enhancing operational efficiency and data-driven decision-making processes. Designed, developed, and deployed sophisticated machine learning models to automate complex regulatory compliance tasks. Deepened technical expertise in Natural Language Processing (NLP) and advanced data analytics while collaborating with cross-functional teams to drive impactful digital transformation initiatives across the organization.',
    year: 'Aug 2025 — Jan 2025'
  },
  {
    title: 'AI Developer · Freelance',
    detail: 'Building intelligent applications using LLMs, RAG, and modern web technologies. delivering custom AI solutions that address specific business needs and drive innovation.',
    year: 'Nov 2023 — Present'
  },
  {
    title: 'Database Manager (SIWES) · Sonet Technology Limited',
    detail: 'Industrial training (SIWES): Managed Oracle databases, data integrity, and day-to-day operations. Assisted with data migration, backups, and performance monitoring; collaborated with teams to ensure reliable data access.',
    year: 'May 2023 — Nov 2023'
  },
  {
    title: 'Software Engineer · Tech Startups',
    detail: 'Developing scalable backend systems and interactive frontend interfaces. Collaborating with agile teams to deliver high-quality software products.',
    year: '2021 — 2023'
  }
]

const capabilities = [
  'Natural Language Processing (NLP)',
  'Large Language Models (LLMs)',
  'RAG & Vector Databases',
  'AI Agents & Automation',
  'Full Stack Development (React/Python)',
  'API Design & Integration'
]

export default function About() {
  return (
    <section className='container py-16 space-y-12'>
      <div className='grid gap-10 lg:grid-cols-[1.1fr,0.9fr] items-start'>
        <div className='card p-8 md:p-10' style={{ borderRadius: '16px' }}>
          <p className='section-label'>About</p>
          <h1 className='mt-4 text-3xl font-normal' style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}>
            Building intelligent systems that solve complex problems.
          </h1>
          <p className='mt-4 text-secondary' style={{ fontFamily: 'DM Sans, sans-serif' }}>
            I’m Adeleke Kehinde — an AI & Full-Stack Developer passionate about
            bridging the gap between cutting-edge AI research and practical applications.
            My work focuses on creating autonomous agents, intelligent assistants, and
            data-driven solutions that drive real value.
          </p>
          <div className='mt-10 grid gap-6'>
            {roles.map(role => (
              <div
                key={role.title}
                className='group'
                style={{ borderLeft: '2px solid var(--border-color)', paddingLeft: '1.5rem', transition: 'border-color 0.3s ease' }}
                onMouseEnter={(e) => e.currentTarget.style.borderColor = 'var(--cta)'}
                onMouseLeave={(e) => e.currentTarget.style.borderColor = 'var(--border-color)'}
              >
                <div className='section-label' style={{ fontSize: '0.7rem' }}>
                  {role.year}
                </div>
                <h3 className='text-lg font-normal mt-2' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif' }}>{role.title}</h3>
                <p className='text-sm text-secondary mt-1' style={{ fontFamily: 'DM Sans, sans-serif' }}>{role.detail}</p>
              </div>
            ))}
          </div>
        </div>

        <aside className='space-y-6'>
          <div className='card-flat p-8'>
            <h4 className='text-base font-normal' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '1.25rem' }}>Capabilities</h4>
            <ul className='mt-5 grid grid-cols-1 gap-3 text-sm text-secondary' style={{ fontFamily: 'DM Sans, sans-serif' }}>
              {capabilities.map(item => (
                <li key={item} className='flex items-center gap-3'>
                  <span className='h-1.5 w-1.5' style={{ background: 'var(--cta)', borderRadius: '1px' }} />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className='card-flat p-8'>
            <h4 className='text-base font-normal' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '1.25rem' }}>Location</h4>
            <p className='text-sm text-secondary mt-1' style={{ fontFamily: 'DM Sans, sans-serif' }}>Lagos, Nigeria — available worldwide</p>

            <div className='mt-6'>
              <h4 className='text-base font-normal' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '1.25rem' }}>Contact</h4>
              <p className='text-sm text-secondary mt-1' style={{ fontFamily: 'DM Sans, sans-serif' }}>kehindeadeleke92@gmail.com</p>
            </div>

            <a
              href='/contact'
              className='btn-primary mt-8 w-full justify-center'
            >
              Request availability
            </a>
          </div>
        </aside>
      </div>
    </section>
  )
}
