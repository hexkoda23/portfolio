import React from 'react'

export default function Contact() {
  return (
    <section className='container py-16'>
      <div className='text-center max-w-2xl mx-auto mb-16 animate-fade-up'>
        <p className='section-label'>Contact</p>
        <h1 className='mt-3 text-3xl sm:text-4xl font-normal' style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}>
          AI Consulting, technical partnerships, and development inquiries.
        </h1>
        <p className='mt-3 text-secondary' style={{ fontFamily: 'DM Sans, sans-serif' }}>
          Share your project requirements, technical challenges, or collaboration ideas.
          I typically reply within 48 hours.
        </p>
      </div>

      <div className='grid gap-8 lg:grid-cols-[0.85fr,1.15fr] items-start'>
        <div className='card-flat p-8 animate-fade-up animate-fade-up-delay-1'>
          <div className="flex items-center gap-3 mb-4">
            <h3 className='text-xl font-normal' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '1.5rem' }}>Availability</h3>
            <span className="flex h-2 w-2 rounded-full" style={{ background: '#22c55e' }} />
          </div>

          <p className='text-sm text-secondary' style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Currently open for freelance AI development projects, technical consulting,
            and long-term partnerships.
          </p>
          <div className='mt-8 space-y-6 text-sm' style={{ fontFamily: 'DM Sans, sans-serif' }}>
            <div>
              <p className='font-semibold mb-1' style={{ color: 'var(--text-primary)' }}>Email</p>
              <a href='mailto:kehindeadeleke92@gmail.com' className='text-secondary hover:text-[var(--cta)] transition-colors'>
                kehindeadeleke92@gmail.com
              </a>
            </div>
            <div>
              <p className='font-semibold mb-1' style={{ color: 'var(--text-primary)' }}>Location</p>
              <p className="text-secondary">Lagos, Nigeria · Remote</p>
            </div>
            <div>
              <p className='font-semibold mb-1' style={{ color: 'var(--text-primary)' }}>Services</p>
              <p className="text-secondary">AI System Design, NLP Solutions, Full Stack Development</p>
            </div>
          </div>
        </div>

        <form className='card-flat p-8 sm:p-10 grid gap-6 animate-fade-up animate-fade-up-delay-2'>
          <div className='grid gap-6 md:grid-cols-2'>
            <div className="grid gap-2">
              <label className='text-[10px] font-bold uppercase tracking-[0.12em] text-muted block' style={{ fontFamily: 'DM Sans, sans-serif' }}>Name</label>
              <input
                className='input'
                placeholder='Your name'
                required
              />
            </div>
            <div className="grid gap-2">
              <label className='text-[10px] font-bold uppercase tracking-[0.12em] text-muted block' style={{ fontFamily: 'DM Sans, sans-serif' }}>Email Address</label>
              <input
                className='input'
                placeholder='you@example.com'
                type='email'
                required
              />
            </div>
          </div>
          <div className="grid gap-2">
            <label className='text-[10px] font-bold uppercase tracking-[0.12em] text-muted block' style={{ fontFamily: 'DM Sans, sans-serif' }}>Company</label>
            <input
              className='input'
              placeholder='Company or organization'
            />
          </div>
          <div className="grid gap-2">
            <label className='text-[10px] font-bold uppercase tracking-[0.12em] text-muted block' style={{ fontFamily: 'DM Sans, sans-serif' }}>Subject / Project Type</label>
            <input
              className='input'
              placeholder='e.g. AI System Design, NLP Analysis'
            />
          </div>
          <div className="grid gap-2">
            <label className='text-[10px] font-bold uppercase tracking-[0.12em] text-muted block' style={{ fontFamily: 'DM Sans, sans-serif' }}>Message</label>
            <textarea
              className='input'
              style={{ minHeight: '140px', resize: 'vertical' }}
              placeholder='Tell me about your project, goals, and any specific requirements...'
              required
            />
          </div>
          <button type='submit' className='btn-primary w-full justify-center py-4'>
            Send request
          </button>
        </form>
      </div>
    </section>
  )
}
