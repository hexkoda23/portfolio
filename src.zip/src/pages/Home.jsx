import Hero from '../components/Hero'
import ProjectCard from '../components/ProjectCard'
import { useNavigate } from 'react-router-dom'

const highlightCards = [
  {
    title: 'Natural Language Processing',
    detail: 'Advanced NLP solutions using embeddings, semantic similarity, and transformer models.',
    meta: 'Building intelligent text analysis and understanding systems.'
  },
  {
    title: 'Machine Learning Engineering',
    detail: 'Production-ready ML systems with anomaly detection, predictive analytics, and model optimization.',
    meta: 'From research to deployment-ready solutions.'
  },
  {
    title: 'AI System Design',
    detail: 'End-to-end AI applications combining multiple technologies for real-world problem solving.',
    meta: 'Architecting scalable, intelligent systems.'
  }
]

const process = [
  {
    stage: 'Research & Analysis',
    description: 'Deep dive into problem space, data exploration, and technology evaluation.',
    duration: 'Week 01'
  },
  {
    stage: 'Architecture Design',
    description: 'System design, model selection, and technical architecture planning.',
    duration: 'Weeks 02—03'
  },
  {
    stage: 'Development & Training',
    description: 'Implementation, model training, testing, and iterative improvement.',
    duration: 'Weeks 04—06'
  },
  {
    stage: 'Deployment & Optimization',
    description: 'Production deployment, monitoring, and continuous performance optimization.',
    duration: 'Launch week'
  }
]

const featuredProjects = [
  {
    title: 'AI Resume & Job Match Scoring System',
    subtitle: 'NLP & Semantic Analysis',
    status: 'Published',
    description:
      'An intelligent system that analyzes CVs and job descriptions to provide match scores, missing skills identification, and personalized improvement recommendations.',
    tags: ['NLP', 'Embeddings', 'FastAPI', 'React'],
    images: ["/ai-resume/ai-resume1.jpg"]
  },
  {
    title: 'Intelligent AI Study Planner',
    subtitle: 'Adaptive Learning Agent',
    status: 'Published',
    description:
      'An AI-powered adaptive learning system that creates personalized study plans and dynamically adjusts them based on user progress and feedback.',
    tags: ['AI Agent', 'Vector DB', 'LLM', 'Next.js'],
    images: ["/ai-study/ai-study1.jpg"]
  }
]

export default function Home() {
  const navigate = useNavigate()

  return (
    <div className='space-y-16 lg:space-y-24'>
      <Hero />

      <section className='container'>
        <div className='flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between mb-12'>
          <div>
            <p className='section-label'>Expertise</p>
            <h2 className='text-3xl font-normal mt-2' style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}>
              Building AI solutions that solve real-world problems.
            </h2>
          </div>
          <p className='text-secondary max-w-xl' style={{ fontFamily: 'DM Sans, sans-serif' }}>
            From concept to deployment, I develop intelligent systems using cutting-edge
            AI technologies including NLP, machine learning, and multimodal AI to create
            practical, impactful solutions.
          </p>
        </div>

        <div className='grid gap-6 md:grid-cols-2 xl:grid-cols-3'>
          {highlightCards.map(card => (
            <div key={card.title} className='card p-6' style={{ borderLeft: '2px solid var(--cta)' }}>
              <div className='section-label mb-3'>
                {card.title}
              </div>
              <p className='text-lg font-medium' style={{ color: 'var(--text-primary)', fontFamily: 'DM Sans, sans-serif' }}>
                {card.detail}
              </p>
              <p className='mt-2 text-sm text-muted' style={{ fontFamily: 'DM Sans, sans-serif' }}>{card.meta}</p>
            </div>
          ))}
        </div>
      </section>

      <section className='container'>
        <div className='p-8 md:p-12 rounded-2xl' style={{ background: 'var(--bg-subtle)', border: '1px solid var(--border-color)' }}>
          <div className='grid gap-8 md:grid-cols-[1.1fr,0.9fr] items-center'>
            <div>
              <p className='section-label'>Technologies</p>
              <h3 className='mt-3 text-3xl font-normal' style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}>
                NLP · Machine Learning · RAG · Multimodal AI
              </h3>
              <p className='mt-4 text-secondary text-base' style={{ fontFamily: 'DM Sans, sans-serif' }}>
                Specializing in practical AI applications that deliver measurable value.
                I combine cutting-edge research with production-ready engineering to build
                systems that solve real business challenges.
              </p>
              <div className='mt-6 flex flex-wrap gap-3'>
                {['Model Development', 'System Architecture', 'Production Deployment'].map(tag => (
                  <span key={tag} className='badge'>
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            <div className='grid gap-4 md:grid-cols-2'>
              <div className='card-flat p-6'>
                <p className='text-sm text-secondary' style={{ fontFamily: 'DM Sans, sans-serif' }}>AI Projects</p>
                <p className='text-3xl font-normal mt-2' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif' }}>9</p>
                <p className='text-xs text-muted' style={{ fontFamily: 'DM Sans, sans-serif' }}>Production-ready solutions</p>
              </div>
              <div className='card-flat p-6'>
                <p className='text-sm text-secondary' style={{ fontFamily: 'DM Sans, sans-serif' }}>Technologies</p>
                <p className='text-3xl font-normal mt-2' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif' }}>15+</p>
                <p className='text-xs text-muted' style={{ fontFamily: 'DM Sans, sans-serif' }}>AI/ML frameworks mastered</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className='container'>
        <div className='flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between mb-10'>
          <div>
            <p className='section-label'>Featured Projects</p>
            <h2 className='text-3xl font-normal mt-2' style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}>
              AI solutions addressing real-world challenges.
            </h2>
          </div>
          <a href='/portfolio' className='btn-primary self-start'>
            See full archive
          </a>
        </div>
        <div className='grid gap-6 md:grid-cols-2'>
          {featuredProjects.map(project => (
            <ProjectCard
              key={project.title}
              {...project}
              onClick={() => navigate('/portfolio')}
            />
          ))}
        </div>
      </section>

      <section className='container pb-20'>
        <div className='rounded-2xl p-8 md:p-12' style={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
          <div className='flex flex-col gap-6 md:flex-row md:items-center md:justify-between mb-12'>
            <div>
              <p className='section-label'>Development Process</p>
              <h2 className='text-3xl font-normal mt-2' style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}>
                A systematic, research-driven approach.
              </h2>
            </div>
            <a href='/contact' className='btn-secondary'>
              Start a project
            </a>
          </div>
          <div className='grid gap-6 md:grid-cols-2 lg:grid-cols-4'>
            {process.map((step, idx) => (
              <div
                key={step.stage}
                className='card-flat p-6 flex flex-col gap-4'
              >
                <div style={{ fontFamily: 'Instrument Serif, Georgia, serif', fontSize: '2.5rem', color: 'var(--cta)', lineHeight: 1 }}>
                  0{idx + 1}
                </div>
                <div>
                  <p className='text-xs font-semibold' style={{ color: 'var(--text-muted)', fontFamily: 'DM Sans, sans-serif', letterSpacing: '0.05em', textTransform: 'uppercase' }}>
                    {step.duration}
                  </p>
                  <h4 className='text-xl font-normal mt-1' style={{ color: 'var(--text-primary)', fontFamily: 'Instrument Serif, Georgia, serif' }}>
                    {step.stage}
                  </h4>
                  <p className='text-sm text-secondary mt-2' style={{ fontFamily: 'DM Sans, sans-serif' }}>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
